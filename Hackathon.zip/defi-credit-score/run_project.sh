
#!/bin/bash
# Run backend
cd backend
npm install
npm start &

# Run frontend
cd ../frontend
npm install
npm start
