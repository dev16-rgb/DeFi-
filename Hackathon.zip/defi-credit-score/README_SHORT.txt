Run backend (set ALCHEMY_API) then start frontend. See README.md for details.
