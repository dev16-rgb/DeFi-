
# DeFi Credit Score

A decentralized finance (DeFi) credit scoring application that evaluates user financial health using blockchain-based metrics.

## 🚀 Features
- **Credit Score Calculation** using DeFi activity
- **React Frontend** with modern UI
- **Node.js Backend** with scoring logic
- **Configurable API** via `.env`

## 📂 Project Structure
```
backend/   → Node.js API for score calculation
frontend/  → React-based user interface
```

## ⚙️ Setup Instructions
1. **Clone the repository**
```bash
git clone <repo_url>
cd defi-credit-score
```

2. **Backend setup**
```bash
cd backend
npm install
cp .env.example .env
npm start
```

3. **Frontend setup**
```bash
cd frontend
npm install
npm start
```

## 🧪 Running Tests
```bash
cd backend
npm test
```

## 📸 Screenshots
_Add screenshots of your app UI here before submission._

## 📜 License
MIT License
