const express = require("express");
const axios = require("axios");
require("dotenv").config();
const { calculateScore } = require("./scoreCalculator");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors());

const ALCHEMY_API = process.env.ALCHEMY_API || "";

app.get("/health", (req, res) => res.json({status: "ok"}));

// Fetch wallet data & return score
app.get("/score/:wallet", async (req, res) => {
  try {
    const wallet = req.params.wallet;

    if (!ALCHEMY_API) {
      return res.status(500).json({error: "ALCHEMY_API not set in env"});
    }

    // Fetch transfers using Alchemy JSON-RPC method alchemy_getAssetTransfers
    const payload = {
      id: 1,
      jsonrpc: "2.0",
      method: "alchemy_getAssetTransfers",
      params: [
        {
          fromAddress: wallet,
          category: ["external", "erc20", "erc721"],
          withMetadata: true,
          excludeZeroValue: true,
          maxCount: "0x64"
        }
      ]
    };

    const txData = await axios.post(
      `https://eth-sepolia.g.alchemy.com/v2/${ALCHEMY_API}`,
      payload,
      { headers: { "Content-Type": "application/json" } }
    );

    const transactions = (txData.data && txData.data.result && txData.data.result.transfers) || [];

    const score = calculateScore(transactions);

    res.json({ wallet, score, txCount: transactions.length, transactions });
  } catch (err) {
    console.error(err && err.toString());
    res.status(500).json({ error: "Error fetching data", details: err && err.toString() });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
