function parseValue(val) {
  // Alchemy returns value in wei sometimes in metadata; we try to be robust.
  try {
    if (!val) return 0;
    // if value is numeric string like "0.5" treat as ETH
    if (typeof val === "string" && val.includes(".")) return parseFloat(val);
    // sometimes value fields are hex wei (e.g. "0x5af3107a4000")
    if (typeof val === "string" && val.startsWith("0x")) {
      return parseInt(val, 16) / 1e18;
    }
    if (typeof val === "number") return val;
    return 0;
  } catch (e) {
    return 0;
  }
}

function calculateScore(transactions) {
  let score = 300; // base score

  if (!transactions || transactions.length === 0) return score;

  // Activity score: more transfers -> more points (capped)
  score += Math.min(transactions.length * 6, 200);

  // Average value and high-value tx bonus
  let totalValue = 0;
  transactions.forEach(tx => {
    const v = parseValue(tx.value || (tx.metadata && tx.metadata.value) || 0);
    totalValue += v;
    if (v >= 1) score += 15;     // big transfer bonus
    else if (v >= 0.1) score += 6; // medium transfer
  });

  const avg = totalValue / Math.max(1, transactions.length);
  if (avg >= 0.5) score += 30;
  else if (avg >= 0.1) score += 10;

  // Recency: reward recent activity (if metadata has blockNum or unix timestamp - best-effort)
  let recentCount = 0;
  const now = Date.now()/1000;
  transactions.forEach(tx => {
    let timestamp = 0;
    if (tx.metadata && tx.metadata.blockTimestamp) {
      timestamp = Date.parse(tx.metadata.blockTimestamp)/1000;
    } else if (tx.blockNum && typeof tx.blockNum === "string" && tx.blockNum.startsWith("0x")) {
      // cannot reliably convert to time here, so skip
      timestamp = 0;
    }
    if (timestamp && (now - timestamp) < 60*60*24*90) recentCount++;
  });
  score += Math.min(recentCount * 5, 50);

  // Normalize and cap between 300 - 850
  score = Math.round(Math.max(300, Math.min(score, 850)));

  return score;
}

module.exports = { calculateScore };
