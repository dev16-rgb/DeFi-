import React, { useState } from "react";
import "./index.css";

function App() {
  const [wallet, setWallet] = useState("");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const fetchScore = async () => {
    setErr("");
    setLoading(true);
    try {
      const res = await fetch(`http://localhost:5000/score/${wallet}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Fetch failed");
      setData(json);
    } catch (e) {
      setErr(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <div className="card">
        <h1>DeFiTrustScore — Demo</h1>
        <input value={wallet} onChange={e => setWallet(e.target.value)} placeholder="Enter wallet address (Sepolia)" />
        <button onClick={fetchScore} disabled={loading || !wallet}>Get Score</button>
        {err && <p className="error">{err}</p>}
        {data && (
          <div className="result">
            <p><strong>Wallet:</strong> {data.wallet}</p>
            <p><strong>Score:</strong> {data.score}</p>
            <p><strong>Tx Count:</strong> {data.txCount}</p>
          </div>
        )}
        <div className="note">
          <p>Tip: Use Sepolia wallet address with some testnet activity. Set backend .env ALCHEMY_API key before running backend.</p>
        </div>
      </div>
    </div>
  );
}

export default App;
